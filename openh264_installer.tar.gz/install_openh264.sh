#!/usr/bin/env bash
set -e

RU="\e[36m"
EN="\e[32m"
ERR="\e[31m"
LINK="\e[34m"
NC="\e[0m"

ARCHIVE_NAME="openh264-2.5.1.tar.gz"
RUNTIME_DIR="/var/lib/flatpak/runtime/org.freedesktop.Platform.openh264/x86_64/2.5.1"

print_logo() {
  echo -e "${RU}"
  cat <<'EOF'
   _____ _                       _____            _    
  / ____| |                     |  __ \          | |   
 | (___ | |_ ___  __ _ _ __ ___ | |  | | ___  ___| | __
  \___ \| __/ _ \/ _` | '_ ` _ \| |  | |/ _ \/ __| |/ /
  ____) | ||  __/ (_| | | | | | | |__| |  __/ (__|   < 
 |_____/ \__\___|\__,_|_| |_| |_|_____/ \___|\___|_|\_\
            / ____|                                    
           | |  __  __ _ _ __ ___   ___  ___           
           | | |_ |/ _` | '_ ` _ \ / _ \/ __|          
           | |__| | (_| | | | | | |  __/\__ \          
            \_____|\__,_|_| |_| |_|\___||___/          
EOF
  echo -e "${LINK}Telegram канал: https://t.me/steamdecks_game${NC}"
}

main_task() {
  echo -e "${RU}RU: Распаковываю внешний архив...${NC}"
  echo -e "${EN}EN: Extracting external archive...${NC}"

  # Путь к архиву теперь указывает на файл в той же директории, что и скрипт
  ARCHIVE_PATH="$(dirname "$0")/$ARCHIVE_NAME"

  # Проверка, существует ли архив
  if [ ! -f "$ARCHIVE_PATH" ]; then
    echo -e "${ERR}RU: Ошибка: Архив '$ARCHIVE_NAME' не найден в директории скрипта!${NC}"
    echo -e "${EN}EN: Error: Archive '$ARCHIVE_NAME' not found in script's directory!${NC}"
    exit 1
  fi

  echo -e "${RU}RU: Создаю директорию: ${RUNTIME_DIR}${NC}"
  sudo mkdir -p "$RUNTIME_DIR"

  echo -e "${EN}EN: Extracting archive to flatpak directory...${NC}"
  sudo tar -xzvf "$ARCHIVE_PATH" -C "$RUNTIME_DIR"

  echo -e "${EN}EN: Running flatpak repair...${NC}"
  sudo flatpak repair

  echo -e "${RU}RU: Проверяю установку...${NC}"
  flatpak info org.freedesktop.Platform.openh264 || {
    echo -e "${ERR}RU: Установка не удалась. Проверьте архив и пути.${NC}"
    exit 1
  }

  echo -e "${EN}✅ Done! OpenH264 установлен.${NC}"
  echo -e "${RU}RU: Открыть Telegram-канал SteamDeck Games? (y/n): ${NC}"
  read -r openlink
  if [[ "$openlink" =~ ^[YyДд]$ ]]; then
    xdg-open "https://t.me/steamdecks_game" &>/dev/null &
  fi

  echo -e "${RU}RU: Скрипт завершён. Окно закроется через 10 секунд.${NC}"
  sleep 10
}

print_logo

echo -e "${RU}RU: Есть ли у вас права sudo?${NC}"
echo "1) Да"
echo "2) Нет, нужно создать пароль"
echo "0) Выход"
read -rp "Выберите 1, 2 или 0: " choice

case "$choice" in
  1) main_task ;;
  2)
    echo -e "${RU}RU: Введите новый пароль для sudo:${NC}"
    sudo passwd
    echo -e "${RU}RU: Повторный запуск установки...${NC}"
    main_task
    ;;
  0)
    echo -e "${RU}Выход.${NC}"
    ;;
  *) echo -e "${ERR}Неверный выбор.${NC}" ;;
esac

exit 0
